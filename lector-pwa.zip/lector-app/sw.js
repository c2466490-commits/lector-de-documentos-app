const CACHE_NAME = 'lector-shell-v1';
const SHELL_FILES = ['./index.html', './manifest.json', './icon-192.png', './icon-512.png'];

self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(SHELL_FILES)).catch(() => {})
  );
});

self.addEventListener('activate', (event) => {
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // Intercept WhatsApp / system "share" -> our app
  if (event.request.method === 'POST' && url.pathname.endsWith('/share-target/')) {
    event.respondWith(handleShareTarget(event));
    return;
  }

  // Basic offline shell caching for the app itself (not for CDN libraries)
  if (event.request.method === 'GET' && url.origin === self.location.origin) {
    event.respondWith(
      caches.match(event.request).then((cached) => cached || fetch(event.request))
    );
  }
});

async function handleShareTarget(event) {
  try {
    const formData = await event.request.formData();
    const file = formData.get('file');
    if (file) {
      const cache = await caches.open('shared-file-store');
      const headers = new Headers();
      headers.set('X-Filename', encodeURIComponent(file.name || 'documento'));
      headers.set('Content-Type', file.type || 'application/octet-stream');
      await cache.put('/shared-file', new Response(file, { headers }));
    }
  } catch (e) {
    // ignore, page will just show the normal empty state
  }
  return Response.redirect('./index.html?shared=true', 303);
}
